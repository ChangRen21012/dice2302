// pages/game1/game1.js
var i=0,newn="",j=0//变量i实现随机数分别赋值nums1和nums2；变量j实现投一次骰子，放置一次
Page({
  /**
   * 页面的初始数据
   */
  data: {
    nums1:"",
    nums2:"",
    //数组array1存放左边棋盘数据，数组array2存放右边棋盘数据
    array1:[{
      id:0,vaule:""
    },{
      id:1,vaule:""
    },{
      id:2,vaule:""
    },{
      id:3,vaule:""
    },{
      id:4,vaule:""
    },{
      id:5,vaule:""
    },{
      id:6,vaule:""
    },{
      id:7,vaule:""
    },{
      id:8,vaule:""
    }],
    array2:[{
      id:0,vaule:""
    },{
      id:1,vaule:""
    },{
      id:2,vaule:""
    },{
      id:3,vaule:""
    },{
      id:4,vaule:""
    },{
      id:5,vaule:""
    },{
      id:6,vaule:""
    },{
      id:7,vaule:""
    },{
      id:8,vaule:""
    }]
  },
  //函数ak1实现将随机数放到左边棋盘对应格子内
  ak1(n){
    let index=n.target.dataset.info
    let n1=this.data.nums1
    let p=this.data.array1[index].vaule
    if(i%2==1&&j==1&&p==''){
      j=0;
      this.setData({
        [`array1[${index}].vaule`]:n1
      })
      var d=Math.floor(index/3)*3;
      for(var m=0;m<3;m++){
        var k=d+m
        let p1=this.data.array2[k].vaule
        if(p1==n1){
          this.setData({
            [`array2[${k}].vaule`]:newn
          })
        }
      }
      for(m=0;m<9;m++){
        let p2=this.data.array1[m].vaule
        if(p2==""){
          break;
        }
      }
      if(m==9){
        var that=this
        that.end()
      }
    }
  },
  //函数ak2实现将随机数放到右边棋盘对应格子内
  ak2(n){
    let index=n.target.dataset.info
    let n2=this.data.nums2
    let p=this.data.array2[index].vaule
    if(i%2==0&&j==1&&p==''){
      j=0;
      this.setData({
        [`array2[${index}].vaule`]:n2
      })
      var d=Math.floor(index/3)*3;
      for(var m=0;m<3;m++){
        var k=d+m
        let p1=this.data.array1[k].vaule
        if(p1==n2){
          this.setData({
            [`array1[${k}].vaule`]:newn
          })
        }
      }
      for(m=0;m<9;m++){
        let p2=this.data.array2[m].vaule
        if(p2==""){
          break;
        }
      }
      if(m==9){
        var that=this
        that.end()
      }
    }
  },
  //随机数
  randomInt(min,max){
    min=Math.ceil(min);
    max=Math.floor(max);
    return Math.floor(Math.random()*(max-min+1))+min;
  },
  //函数getNums获取一个随机数
  getNums(){
    if(j==0){
      let news=""+this.randomInt(1,6);
      i++;
      j++;
      if(i%2==1){
        this.setData({
          nums1:news,
          nums2:""
        })
      }
      else{
        this.setData({
          nums2:news,
          nums1:""
        })
      }
    }
  },
  //函数end进行结算
  end(){
    var nmm1=0,nmm2=0,a=[1,1,1]
    for(var d=0;d<3;d++){
      var k=d*3
      var m=k
      let p1=Number(this.data.array1[m].vaule)
      m++;
      let p2=Number(this.data.array1[m].vaule)
      m++;
      let p3=Number(this.data.array1[m].vaule)
      if(p1==p2){
        a[0]++;
        a[1]++;
      }
      if(p1==p3){
        a[0]++;
        a[2]++;
      }
      if(p2==p3){
        a[1]++;
        a[2]++;
      }
      nmm1+=a[0]*p1+a[1]*p2+a[2]*p3;
      a[0]=1;
      a[1]=1;
      a[2]=1;
      m=k;
      let p4=Number(this.data.array2[m].vaule)
      m++;
      let p5=Number(this.data.array2[m].vaule)
      m++;
      let p6=Number(this.data.array2[m].vaule)
      if(p4==p5){
        a[0]++;
        a[1]++;
      }
      if(p4==p6){
        a[0]++;
        a[2]++;
      }
      if(p5==p6){
        a[1]++;
        a[2]++;
      }
      nmm2+=a[0]*p4+a[1]*p5+a[2]*p6;
      a[0]=1;
      a[1]=1;
      a[2]=1;
      m=k;
      this.setData({
        [`array1[${m}].vaule`]:newn,
        [`array2[${m}].vaule`]:newn,
      })
      m++;
      this.setData({
        [`array1[${m}].vaule`]:newn,
        [`array2[${m}].vaule`]:newn,
      })
      m++;
      this.setData({
        [`array1[${m}].vaule`]:newn,
        [`array2[${m}].vaule`]:newn
      })
    }
    i=0;
    j=0;
    this.setData({
      nums2:"",
      nums1:""
    })
    this.jxyx()
    if(nmm1>nmm2){
      wx.showModal({
        title:"玩家A获胜",
        content:"玩家A得分为"+nmm1+" "+"玩家B得分为"+nmm2
      })
    }
    else if(nmm1==nmm2){
      wx.showModal({
        title:"玩家A与玩家B平局",
        content:"玩家A得分为"+nmm1+" "+"玩家B得分为"+nmm2
      })
    }
    else{
      wx.showModal({
        title:"玩家B获胜",
        content:"玩家A得分为"+nmm1+" "+"玩家B得分为"+nmm2
      })
    }
  },
  //页面加载时弹出窗口
  onLoad(options){
    wx.showModal({
      title:"开始游戏",
      content:"是否开始游戏",
      success (res) {
        if (res.cancel) {
          wx.navigateTo({
            url: '/pages/start/start',
          })
        }else if(res.confirm){
          i=0;
        }
      }
    })
  },
  //结算一次后弹出窗口
  jxyx(){
    wx.showModal({
      title:"继续游戏",
      content:"是否继续游戏",
      success (res) {
        if (res.cancel) {
          wx.navigateTo({
            url: '/pages/start/start',
          })
        }
      }
    })
  }
})