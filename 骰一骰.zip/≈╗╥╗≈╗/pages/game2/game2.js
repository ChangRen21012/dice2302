// pages/game2/game2.js
var i=0,newn="",j=0//变量i实现随机数分别赋值nums1和nums2；变量j实现投一次骰子，放置一次
Page({
  /**
   * 页面的初始数据
   */
  data: {
    nums1:"",
    nums2:"",
    //数组array1存放左边棋盘数据，数组array2存放右边棋盘数据
    array1:[{
      id:0,vaule:""
    },{
      id:1,vaule:""
    },{
      id:2,vaule:""
    },{
      id:3,vaule:""
    },{
      id:4,vaule:""
    },{
      id:5,vaule:""
    },{
      id:6,vaule:""
    },{
      id:7,vaule:""
    },{
      id:8,vaule:""
    }],
    array2:[{
      id:0,vaule:""
    },{
      id:1,vaule:""
    },{
      id:2,vaule:""
    },{
      id:3,vaule:""
    },{
      id:4,vaule:""
    },{
      id:5,vaule:""
    },{
      id:6,vaule:""
    },{
      id:7,vaule:""
    },{
      id:8,vaule:""
    }]
  },
  //页面加载时弹出窗口
  onLoad(options){
    var that=this
    wx.showModal({
      title:"开始游戏",
      content:"是否开始游戏",
      success (res) {
        if (res.cancel) {
          wx.navigateTo({
            url: '/pages/start/start',
          })
        }else if(res.confirm){
          i=0;
          that.xhs()
        }
      }
    })
  },
  //函数ak1实现将随机数放到左边棋盘对应格子内
  ak1(n){
    let index=n.target.dataset.info
    let n1=this.data.nums1
    let p=this.data.array1[index].vaule
    if(i%2==1&&j==1&&p==''){
      j=0;
      this.setData({
        [`array1[${index}].vaule`]:n1
      })
      var d=Math.floor(index/3)*3;
      for(var m=0;m<3;m++){
        var k=d+m
        let p1=this.data.array2[k].vaule
        if(p1==n1){
          this.setData({
            [`array2[${k}].vaule`]:newn
          })
        }
      }
      for(m=0;m<9;m++){
        let p2=this.data.array1[m].vaule
        if(p2==""){
          break;
        }
      }
      if(m==9){
        this.end()
      }
      else{
        this.ak2()
      }
    }
  },
  //函数ak2实现将随机数放到右边棋盘对应格子内
  ak2(){
    this.getNums()
    let n2=this.data.nums2
    var index=this.nextStep(n2)
    let p=this.data.array2[index].vaule
    if(i%2==0&&j==1&&p==''){
      j=0;
      this.setData({
        [`array2[${index}].vaule`]:n2
      })
      var d=Math.floor(index/3)*3;
      for(var m=0;m<3;m++){
        var k=d+m
        let p1=this.data.array1[k].vaule
        if(p1==n2){
          this.setData({
            [`array1[${k}].vaule`]:newn
          })
        }
      }
      for(m=0;m<9;m++){
        let p2=this.data.array2[m].vaule
        if(p2==""){
          break;
        }
      }
      if(m==9){
        this.end()
      }
    }
  },
  //函数nextStep计算人机落点处
  nextStep(n){
    var index,a1=[0,0,0],a2=[0,0,0],b1=[0,0,0],b2=[0,0,0],c=[0,0,0]
    for(var m=0;m<3;m++){
      var k=m*3
      for(var d=0;d<3;d++){
        var s=k+d
        let p1=this.data.array1[s].vaule
        let p2=this.data.array2[s].vaule
        if(p1!=''){
          a1[m]++
          if(p1==n){
            a2[m]++
          }
        }
        if(p2!=''){
          b1[m]++
          if(p2==n){
            b2[m]++
          }
        }
      }
      if(b1[m]!=3){
        c[m]++
      }
    }
    var u=Number(n)
    for(m=0;m<3;m++){
      if(c[m]!=0){
        if(u>2){
          c[m]+=(a2[m]*3)
          c[m]+=(b2[m]*3)
          c[m]+=a1[m]
          c[m]+=(3-b1[m])
        }
        else if(u==2){
          if(a1[m]!=3){
            c[m]+=a2[m]*2
            c[m]+=(b2[m]*3+1)
            c[m]+=(3-a1[m])
            c[m]+=(3-b1[m])
          }
        }
        else{
          if(a1[m]!=3){
            c[m]+=(b2[m]*3+1)
            c[m]+=(3-a1[m])
            c[m]+=(3-b1[m])
          }
        }
      }
    }
    var max=c[0],x=0
    for(m=1;m<3;m++){
      if(c[m]>max){
        max=c[m]
        x=m
      }
    }
    for(m=0;m<3;m++){
      index=x*3+m
      let p=this.data.array2[index].vaule
      if(p==''){
        break;
      }
    }
    return index
  },
  //随机数
  randomInt(min,max){
    min=Math.ceil(min);
    max=Math.floor(max);
    return Math.floor(Math.random()*(max-min+1))+min;
  },
  //函数getNums获取一个随机数
  getNums(){
    if(j==0){
      let news=""+this.randomInt(1,6);
      i++;
      j++;
      if(i%2==1){
        this.setData({
          nums1:news,
          nums2:""
        })
      }
      else{
        this.setData({
          nums2:news,
          nums1:""
        })
      }
    }
  },
  //函数end进行结算
  end(){
    var nmm1=0,nmm2=0,a=[1,1,1]
    for(var d=0;d<3;d++){
      var k=d*3
      var m=k
      let p1=Number(this.data.array1[m].vaule)
      m++;
      let p2=Number(this.data.array1[m].vaule)
      m++;
      let p3=Number(this.data.array1[m].vaule)
      if(p1==p2){
        a[0]++;
        a[1]++;
      }
      if(p1==p3){
        a[0]++;
        a[2]++;
      }
      if(p2==p3){
        a[1]++;
        a[2]++;
      }
      nmm1+=a[0]*p1+a[1]*p2+a[2]*p3;
      a[0]=1;
      a[1]=1;
      a[2]=1;
      m=k;
      let p4=Number(this.data.array2[m].vaule)
      m++;
      let p5=Number(this.data.array2[m].vaule)
      m++;
      let p6=Number(this.data.array2[m].vaule)
      if(p4==p5){
        a[0]++;
        a[1]++;
      }
      if(p4==p6){
        a[0]++;
        a[2]++;
      }
      if(p5==p6){
        a[1]++;
        a[2]++;
      }
      nmm2+=a[0]*p4+a[1]*p5+a[2]*p6;
      a[0]=1;
      a[1]=1;
      a[2]=1;
      m=k;
      this.setData({
        [`array1[${m}].vaule`]:newn,
        [`array2[${m}].vaule`]:newn,
      })
      m++;
      this.setData({
        [`array1[${m}].vaule`]:newn,
        [`array2[${m}].vaule`]:newn,
      })
      m++;
      this.setData({
        [`array1[${m}].vaule`]:newn,
        [`array2[${m}].vaule`]:newn
      })
    }
    i=0;
    j=0;
    this.setData({
      nums2:"",
      nums1:""
    })
    this.jxyx()
    if(nmm1>nmm2){
      wx.showModal({
        title:"玩家获胜",
        content:"玩家得分为"+nmm1+" "+"电脑得分为"+nmm2
      })
    }
    else if(nmm1==nmm2){
      wx.showModal({
        title:"玩家与电脑平局",
        content:"玩家得分为"+nmm1+" "+"电脑得分为"+nmm2
      })
    }
    else{
      wx.showModal({
        title:"电脑获胜",
        content:"玩家得分为"+nmm1+" "+"电脑得分为"+nmm2
      })
    }
  },
  //函数啊xhs实现弹出窗口选择先后手
  xhs(){
    var that=this
    wx.showModal({
      title:"先手/后手",
      content:"请选择先手/后手",
      confirmText:"后手",
      cancelText:"先手",
      success (res) {
        if (res.confirm) {
          i=1;
          that.ak2();
        } else if(res.cancel){
          i=0;
        }
      }
    })
  },
  //结算一次后弹出窗口
  jxyx(){
    var that=this
    wx.showModal({
      title:"继续游戏",
      content:"是否继续游戏",
      success (res) {
        if (res.cancel) {
          wx.navigateTo({
            url: '/pages/start/start',
          })
        }else if(res.confirm){
          that.xhs()
        }
      }
    })
  }
})