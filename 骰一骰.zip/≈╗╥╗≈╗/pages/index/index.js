// index.js
Page({
  jumpPage(){
    wx.navigateTo({
      url: '/pages/start/start',
    })
  }
})
