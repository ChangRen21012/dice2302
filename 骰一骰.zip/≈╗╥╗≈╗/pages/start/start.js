// pages/start/start.js
Page({
  jumpPage1(){
    wx.navigateTo({
      url: '/pages/game1/game1',
    })
  },
  jumpPage2(){
    wx.navigateTo({
      url: '/pages/game2/game2',
    })
  },
  jumpPage3(){
    wx.navigateTo({
      url: '/pages/gamerule/gamerule',
    })
  },
})