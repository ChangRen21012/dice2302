// pages/gamerule/gamerule.js
Page({})